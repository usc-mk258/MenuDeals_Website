define({
  "title": "Doc for restaurant",
  "url": "http://localhost:3200",
  "name": "restaurant",
  "version": "0.0.1",
  "description": "Awesome project developed with TypeORM.",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2020-05-10T20:41:58.206Z",
    "url": "http://apidocjs.com",
    "version": "0.20.0"
  }
});
